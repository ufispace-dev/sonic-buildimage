#!/usr/bin/env bash
#
# Script to collect platform platform sopecific techsupport dump 
#

DUMPDIR="/tmp"
BCMCMD_PRECHECK_TIMEOUT_MIN=1
TIMEOUT_MIN="1"
SKIP_BCMCMD=0
sai_dump_name="sai_sdk_dump_$(date +"%m_%d_%Y_%I_%M_%p")"
sai_dump_path="${DUMPDIR}/$sai_dump_name"
mkdir -p $sai_dump_path
sai_dump_file="${sai_dump_path}/$sai_dump_name"

save_bcmcmd() {
    local cmd="$1"
    local precheck=${2:-false}
    local filepath="$sai_dump_file"
   
    local timeout_cmd="timeout --foreground ${TIMEOUT_MIN}m"
    local timeout_cmd_precheck="timeout --foreground ${BCMCMD_PRECHECK_TIMEOUT_MIN}m"
    [ ! -d $DUMPDIR ] && $MKDIR $V -p $DUMPDIR

    #Check BCMSHELL is busy or already in use. Only one connection allowed
    #First command used (ie version ) used to check the shell status
    if $precheck; then
        eval "${timeout_cmd_precheck} $cmd" &> /dev/null
        ret=$?
        if [ $ret -ne 0 ]; then
            if [ $ret -eq 124 ]; then
                echo "Command: $cmd timedout after ${BCMCMD_PRECHECK_TIMEOUT_MIN} minutes."
                SKIP_BCMCMD=1
            fi
        fi
    fi

    if [ $SKIP_BCMCMD -eq 1 ]; then
        echo "Skip $cmd"
        return 0
    fi

    # eval required here to re-evaluate the $cmd properly at runtime
    eval "${timeout_cmd} $cmd" &> /dev/null
    ret=$?
    if [ $ret -ne 0 ]; then
       if [ $ret -eq 124 ]; then
          echo "Command: $cmd timedout after ${TIMEOUT_MIN} minutes."
       else
          grep "polling socket timeout: Success" ${filepath} &>/dev/null
          if [ $? -eq 0 ]; then
             echo "bcmcmd command timeout. Setting SKIP_BCMCMD to true ..."
             SKIP_BCMCMD=1
          fi  
       fi
    fi
}

#Collects SAI techsupport dump
save_bcmcmd "bcmcmd \"BCMSAI TechSupport File $sai_dump_file Append\""
#collect SDK techsupport dump
chip_type=None
#First command checks the bcmshell accessability
save_bcmcmd "bcmcmd -t5 version" true
if [ $SKIP_BCMCMD -eq 0 ]; then
    chip_type=$(bcmcmd -t5 "show unit" | grep BCM)
fi
save_bcmcmd "bcmcmd \"console off\""
save_bcmcmd "bcmcmd \"log file=$sai_dump_file append=yes on\""
if [[ "$chip_type" == *"BCM5652"* || "$chip_type" == *"BCM5653"* ||
      "$chip_type" == *"BCM5683"* || "$chip_type" == *"BCM5684"* ||
      "$chip_type" == *"BCM5685"* || "$chip_type" == *"BCM5686"* ||
      "$chip_type" == *"BCM5664"* || "$chip_type" == *"BCM5654"* ||
      "$chip_type" == *"BCM5616"* || "$chip_type" == *"BCM5604"* ||
      "$chip_type" == *"BCM5634"* || "$chip_type" == *"BCM5687"* ||
      "$chip_type" == *"BCM5677"* || "$chip_type" == *"BCM5637"* ||
      "$chip_type" == *"BCM5697"* || "$chip_type" == *"BCM5695"* ||
      "$chip_type" == *"BCM5696"* || "$chip_type" == *"BCM5698"* ||
      "$chip_type" == *"BCM5662"* || "$chip_type" == *"BCM5663"* ||
      "$chip_type" == *"BCM5664"* || "$chip_type" == *"BCM5668"* ]]; then
    save_bcmcmd "bcmcmd \"techsupport basic\""
fi
if [[ "$chip_type" == *"BCM5688"* || "$chip_type" == *"BCM5699"* ||
      "$chip_type" == *"BCM5669"* || "$chip_type" == *"BCM5678"* ||
      "$chip_type" == *"BCM5688"* || "$chip_type" == *"BCM5689"* ]]; then
    save_bcmcmd "bcmcmd \"ts basic\""
fi

cd "${DUMPDIR}"
tar -cvf "$sai_dump_name".tar $sai_dump_name
gzip "$sai_dump_name".tar
rm -rf $sai_dump_name
